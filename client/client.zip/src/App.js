import "./App.css";
import React from "react";
import UserRoutes from "./routes/UserRoutes";

function App() {
  return (
    <>
      <UserRoutes />
    </>
  );
}

export default App;
